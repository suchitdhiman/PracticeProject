package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class App 
{
    public static void main( String[] args )
    {
       // register chrome driver 
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver-win32\\chromedriver.exe");
    //create an object to the driver to access the browser componenets 
    	WebDriver wd=new ChromeDriver();
    	//maximize the browser 
    	wd.manage().window().maximize();
    	//to open web url -> localhost , www.
    	wd.get("http://127.0.0.1:5500/Registration.html");
//    	wd.findElement(By.id("twotabsearchtextbox")).sendKeys("samsung mobiles");
//    	wd.findElement(By.xpath("//*[@id=\"nav-search-submit-button\"]")).click();
    	//close the browser
    	//using hyperlink
    	
    	//Registration
//    	wd.findElement(By.linkText("Start here.")).click();
    	wd.findElement(By.id("username")).sendKeys("suchit");
    	wd.findElement(By.id("password")).sendKeys("12345");
    	wd.findElement(By.id("confirmPassword")).sendKeys("12345");
    	wd.findElement(By.id("email")).sendKeys("suchit@gmail.com");
    	wd.findElement(By.id("register")).click();
    	
    	//login
    	wd.findElement(By.id("loginUsername")).sendKeys("suchit");
    	wd.findElement(By.id("loginPassword")).sendKeys("12345");
    	wd.findElement(By.id("submit")).click();
    	
    	
    
//    	wd.close();
    }
}
