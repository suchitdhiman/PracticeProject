package SeleniumTestNGOne.TestNG;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class WebsiteAutomationTest {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        // Set the path to the Chrome WebDriver executable
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);
    }

    @Test(priority = 1)
    public void testRegistration() {
        // Navigate to the registration page
        driver.get("http://127.0.0.1:5500/Registration.html");

        // Fill in registration form
       
    	
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement confirmPasswordField = driver.findElement(By.id("confirmPassword"));
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement registerButton = driver.findElement(By.id("register"));

        usernameField.sendKeys("testuser");
        passwordField.sendKeys("password123");
        confirmPasswordField.sendKeys("password123");
        emailField.sendKeys("suchit@gmail.com");
        registerButton.click();

//        // Check if registration is successful (you may need to assert against a success message)
//        WebElement successMessage = driver.findElement(By.id("registrationSuccessMessage"));
//        Assert.assertTrue(successMessage.isDisplayed());
    }

    @Test(priority = 2)
    public void testValidLogin() {
        // Navigate to the login page
        driver.get("http://127.0.0.1:5500/login.html");
    
        WebElement usernameField = driver.findElement(By.id("loginUsername"));
        WebElement passwordField = driver.findElement(By.id("loginPassword"));
        WebElement loginButton = driver.findElement(By.id("sumit"));

        usernameField.sendKeys("suchit");
        passwordField.sendKeys("12345");
        loginButton.click();

//        // Fill in login form with invalid credentials
//        WebElement usernameField = driver.findElement(By.id("loginUsername"));
//        WebElement passwordField = driver.findElement(By.id("loginPassword"));
//        WebElement loginButton = driver.findElement(By.id("submit"));
//
//        usernameField.sendKeys("testuser");
//        passwordField.sendKeys("wrongpassword");
//        loginButton.click();
//
//        // Check for an error message (you may need to assert against an error message)
//        WebElement errorMessage = driver.findElement(By.id("loginErrorMessage"));
//        Assert.assertTrue(errorMessage.isDisplayed());
    }

    @Test(priority = 3)
    public void testSearchAndAddToCart() {
        // Log in with valid credentials
//        driver.get("http://127.0.0.1:5500/login.html");
//        WebElement usernameField = driver.findElement(By.id("loginUsername"));
//        WebElement passwordField = driver.findElement(By.id("loginPassword"));
//        WebElement loginButton = driver.findElement(By.id("sumit"));
//
//        usernameField.sendKeys("suchit");
//        passwordField.sendKeys("12345");
//        loginButton.click();

        // Search for a product
//        WebElement searchBar = driver.findElement(By.id("searchBar"));
//        WebElement searchButton = driver.findElement(By.id("searchButton"));
//
//        searchBar.sendKeys("Product Name");
//        searchButton.click();

//        // Click on a product to view details
//        WebElement productLink = driver.findElement(By.linkText("Product Name"));
//        productLink.click();

        // Add the product to the cart
        WebElement addToCartButton = driver.findElement(By.xpath("/html/body/section/div[2]/button"));
        addToCartButton.click();

        // Verify that the product is in the cart (you may need to assert against cart contents)
//        WebElement cartContents = driver.findElement(By.id("cart"));
//        Assert.assertTrue(cartContents.getText().contains("Product1"));
    }

    @AfterClass
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
