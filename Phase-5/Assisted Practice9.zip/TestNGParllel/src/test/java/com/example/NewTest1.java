package com.example;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewTest1 {
  
  @Test
  public void f2() {
	  System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win32\\chromedriver.exe");
	    //create an object to the driver to access the browser componenets 
	    	WebDriver wd=new ChromeDriver();
	    	//maximize the browser 
	    	wd.manage().window().maximize();
	    	wd.get("https://www.amazon.in/");
	    	wd.close();
  }
}
