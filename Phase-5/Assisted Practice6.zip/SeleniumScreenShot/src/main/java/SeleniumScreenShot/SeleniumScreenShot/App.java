package SeleniumScreenShot.SeleniumScreenShot;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class App 
{
    public static void main( String[] args ) throws IOException
    {
    	WebDriver wd=null;
    	try{
    		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win32\\chromedriver.exe");
    		  //create an object to the driver to access the browser componenets 
        	wd=new ChromeDriver();
        	//maximize the browser 
        	wd.manage().window().maximize();
                                                                               //8000 for successful flow image
        	wd.manage().timeouts().pageLoadTimeout(8000, TimeUnit.MILLISECONDS);
        	wd.get("https://www.amazon.in/");
        	wd.findElement(By.linkText("Help")).click(); 
        	takeScreenShot(wd,"amazon");
        	wd.close();

    	}
    	
    		catch (Exception e) {
//        		takeScreenShot(wd,"amazon");
//    		
//
		}

    }

    public static void takeScreenShot(WebDriver wd,String fileName) throws IOException {
    	// take a screen shot and make it as a file 
    	File file=((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
    	//copy the file to a location with the extension 
    	FileUtils.copyFile(file,new File("D:\\"+fileName+".png"));
    }

}
