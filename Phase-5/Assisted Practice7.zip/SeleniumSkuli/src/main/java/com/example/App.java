package com.example;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;




public class App 
{
    public static void main( String[] args ) throws InterruptedException, IOException, FindFailed
    {
       // register chrome driver 
    	
    	System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win32\\chromedriver.exe");
    //create an object to the driver to access the browser componenets 
    	WebDriver wd=new ChromeDriver();
    	//maximize the browser 
    	wd.manage().window().maximize();
    	wd.manage().timeouts().pageLoadTimeout(8000, TimeUnit.MILLISECONDS);
    	wd.get("https://www.ilovepdf.com/pdf_to_word");
Screen sc=new Screen();

    Pattern p1=new Pattern("D:\\image1.png");
    sc.click(p1);
    Pattern p2=new Pattern("D:\\image2.png");
    sc.type(p2,"D:\\angular.pdf");
    Pattern p3=new Pattern("D:\\image3.png");
   sc.click(p3);

    }	
}
