package SeleniumImplicitExplicite.SeleniumExplicite;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class App 
{
    public static void main( String[] args )
    {
    	System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win32\\chromedriver.exe");
      WebDriver wd = new ChromeDriver();
      wd.manage().window().maximize();
      wd.manage().timeouts().pageLoadTimeout(2000,TimeUnit.MILLISECONDS);
      wd.get("http://127.0.0.1:5500/registerationTesting.html");
      WebElement we1 = wd.findElement(By.name("id"));
      WebElement we2 = wd.findElement(By.name("op"));
      
//      explicit(wd,we1,200,"2");
      explicitSelect(wd,we2,200);
      
    }
    private static void explicitSelect(WebDriver wd, WebElement we2, int timebound) {
		// TODO Auto-generated method stub
		new WebDriverWait(wd, timebound).until(ExpectedConditions.visibilityOf(we2));
		Select sc=new Select(wd.findElement(By.name("op")));
	   	sc.selectByVisibleText("JAVA");
	}

//	private static void explicit(WebDriver wd, WebElement we1, int timebound, String value) {
//		// TODO Auto-generated method stub
//		new WebDriverWait(wd,timebound).until(ExpectedConditions.visibilityOf(we1));
//		we1.sendKeys(value);
//	}
}
