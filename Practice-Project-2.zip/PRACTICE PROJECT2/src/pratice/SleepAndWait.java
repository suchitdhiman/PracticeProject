package pratice;

class ObjectExample extends Object{

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		System.out.println("This is temporary object for demonstraiong the exapmle of Sleep and Wait funtion ");
		return "";
	}
	
}

public class SleepAndWait {
	private static Object obj = new ObjectExample();   
	  
		public static void main(String[] args) throws InterruptedException {
			 Thread.sleep(2000);   
		     System.out.println( Thread.currentThread().getName() +   
		        " Thread is woken after two second");   
		        synchronized (obj)    
		        {   
		            //use wailt() method to set obj in waiting state for two seconds  
		            obj.wait(2000);   
		  
		            System.out.println(obj.toString() + " Object is in waiting state and woken after 2 seconds");   
		        }   
		    }   
}
