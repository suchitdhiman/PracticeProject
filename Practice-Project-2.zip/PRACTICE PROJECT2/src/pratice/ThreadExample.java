package pratice;

//Creating a thread by extending the Thread class
class MyThread extends Thread{

	 @Override
	    public void run() {
	        System.out.println("Thread created by extending Thread class.");
	    }
}

//Creating a thread by implementing the Runnable interface
class MyRunnable implements Runnable {
 @Override
 public void run() {
     System.out.println("Thread created by implementing Runnable interface.");
 }
}
public class ThreadExample {
	 public static void main(String[] args) {
	        // Creating a thread by extending the Thread class
	        MyThread thread1 = new MyThread();
	        thread1.start();

	        // Creating a thread by implementing the Runnable interface
	        // we can not directly initiate the object of runnable class because it is is interface
	        Thread thread2 = new Thread(new MyRunnable());
	        thread2.start();
	 }
}
