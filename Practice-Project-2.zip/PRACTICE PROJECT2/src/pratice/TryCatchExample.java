package pratice;

import java.util.Scanner;

public class TryCatchExample {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		try {
			System.out.println("Enter dividend : ");
			int dividend=sc.nextInt();
			System.out.println("Enter Divisor : ");
			int divisor=sc.nextInt();
			System.out.println(dividend/divisor);
		}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Devisior can not be Zero");
		}
		catch (NumberFormatException e) {
			// TODO: handle exception
			System.out.println("Enter Integer only");
		}
	}
}
