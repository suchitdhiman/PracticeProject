package pratice;
// Diamond problem in java state that why we don't use the concept of multiple inheritence in java
interface Animal {
    default void sound() {
        System.out.println("Default sound");
    }
}

interface Cat extends Animal {
    default void sound() {
        System.out.println("Meow");
    }
}

interface Dog extends Animal {
    default void sound() {
        System.out.println("Woof");
    }
}

class AnimalSound implements Cat, Dog {
    public void sound() {
        Cat.super.sound();  // Resolve ambiguity by explicitly calling Cat's sound method
        Dog.super.sound();  // Resolve ambiguity by explicitly calling Dog's sound method
    }
}

public class  DiamondExample {
    public static void main(String[] args) {
        AnimalSound animalSound = new AnimalSound();
        animalSound.sound();
    }
}

