package pratice;


// we use here synchronized keyword to maintain the work-flow of threads with count variable in simple
// word we can say that only one thread can work at a time on count variable
public class synchronizedThredExample {
	  private int count = 0;

	    public synchronized void increment() {
	        count++;
	    }

	    public synchronized void decrement() {
	        count--;
	    
	    }
	    public synchronized int getCount() {
	        return count;
	    }

	    public static void main(String[] args) throws InterruptedException {
	    	synchronizedThredExample example = new synchronizedThredExample();

	        // Create multiple threads to increment and decrement the count
	        Thread incrementThread = new Thread(() -> {
	            for (int i = 0; i < 1000; i++) {
	                example.increment();
	            }
	        });

	        Thread decrementThread = new Thread(() -> {
	            for (int i = 0; i < 1000; i++) {
	                example.increment();
	            }
	        });

	        // Start the threads
	        incrementThread.start();
	        decrementThread.start();

	        // Wait for the threads to finish
	        incrementThread.join();
	        decrementThread.join();

	        // Print the final count value
	        System.out.println("Final count: " + example.getCount());
	    }
}
