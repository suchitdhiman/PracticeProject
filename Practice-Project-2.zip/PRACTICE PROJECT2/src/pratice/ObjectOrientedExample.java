package pratice;
//Shape.java - Parent class
abstract class Shape {
 protected String color;
 
 public Shape(String color) {
     this.color = color;
 }
 
 public abstract double getArea();
 
 public abstract double getPerimeter();
 
 public void display() {
     System.out.println("Color: " + color);
     System.out.println("Area: " + getArea());
     System.out.println("Perimeter: " + getPerimeter());
 }
}

//Circle.java - Child class inheriting from Shape
class Circle extends Shape {
 private double radius;
 
 public Circle(String color, double radius) {
     super(color);
     this.radius = radius;
 }
 
 @Override
 public double getArea() {
     return Math.PI * radius * radius;
 }
 
 @Override
 public double getPerimeter() {
     return 2 * Math.PI * radius;
 }
}

//Rectangle.java - Child class inheriting from Shape
class Rectangle extends Shape {
 private double length;
 private double width;
 
 public Rectangle(String color, double length, double width) {
     super(color);
     this.length = length;
     this.width = width;
 }
 
 @Override
 public double getArea() {
     return length * width;
 }
 
 @Override
 public double getPerimeter() {
     return 2 * (length + width);
 }
}

//Main class
public class ObjectOrientedExample {
 public static void main(String[] args) {
     // Create objects
     Circle circle = new Circle("Red", 5.0);
     Rectangle rectangle = new Rectangle("Blue", 3.0, 4.0);
     
     // Display shape properties
     circle.display();
     System.out.println("-----------");
     rectangle.display();
 }
}
