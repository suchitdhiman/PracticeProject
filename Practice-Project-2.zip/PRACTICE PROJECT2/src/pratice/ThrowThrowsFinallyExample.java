package pratice;

public class ThrowThrowsFinallyExample {

    public static void main(String[] args) {
        try {
            divideNumbers(10, 0);
        } catch (CustomException ce) {
            System.out.println("CustomException caught: " + ce.getMessage());
        } finally {
            System.out.println("Inside finally block");
        }
    }

    public static void divideNumbers(int dividend, int divisor) throws CustomException {
        if (divisor == 0) {
            throw new CustomException("Cannot divide by zero");
        }

        int result = dividend / divisor;
        System.out.println("Result: " + result);
    }

    public static class CustomException extends Exception {
		public CustomException(String message) {
            super(message);
        }
    }
}
