package pratice;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class FileHandleExample {
	public static Scanner scanner=new Scanner(System.in);
	public static void  creatFile(String fileName) {
		try {
			File file=new File(fileName);
			if(file.createNewFile()) {
				System.out.println("File is Created "+ file.getAbsoluteFile());
			}
			else {
				System.out.println("File is already exist");
			}
		}
		catch(Exception e) {
			System.out.println("An Error occured during creating file Template.txt");
			e.printStackTrace();
		}
	}
	public static String ReadFile(String fileName) {
		StringBuilder builder=new StringBuilder();
		try {
			BufferedReader reader=new BufferedReader(new  FileReader(fileName));
			String linebyline;
			while((linebyline=reader.readLine())!=null) {
				builder.append(linebyline);
			}
		}catch (Exception e) {
			System.out.println("An Error occured during creating file Template.txt");
			e.printStackTrace();
		}
		return builder.toString();
	}
	public static void writeFile(String fileName) {
		try {
		FileWriter writer=new FileWriter(fileName);
	      String Content= scanner.nextLine();
	    writer.write(Content);
	    System.out.println("content is added to the Template.txt file");
	    writer.close();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("An Error occured during creating file Template.txt");
			e.printStackTrace();
		}
	}
	public static void updateFile(String fileName) {
		try {
			FileWriter writer=new FileWriter(fileName);
			 String updateContent= scanner.nextLine();
			 String existContent=FileHandleExample.ReadFile(fileName);
			 String newContent=existContent+updateContent;
			 System.out.println(existContent);
			writer.append(newContent);
			System.out.println("Template.txt file is updated");
			writer.close();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("An Error occured during creating file Template.txt");
			e.printStackTrace();
		}
	}
	public static void deleteFile(String filneNme) {
		try {
			File file=new File(filneNme);
			 if (!file.delete()) {
		            System.out.println("File deleted: " + file.getName());
		        } else {
		            System.out.println("Failed to delete the file.");
		        }
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("An Error occured during creating file Template.txt");
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		String fileName="Template.txt";
		// creating the new file with given fileName
		FileHandleExample.creatFile(fileName);
		// writng the first content in file
		FileHandleExample.writeFile(fileName);
		// updateing the file
		FileHandleExample.updateFile(fileName);
		// reading the file
		String fileContent=FileHandleExample.ReadFile(fileName);
		System.out.println(fileContent);
		// Deleting the file
		FileHandleExample.deleteFile(fileName);
		
	}
}
