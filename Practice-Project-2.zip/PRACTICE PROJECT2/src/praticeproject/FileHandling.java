package praticeproject;

	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.util.Scanner;

	public class FileHandling {
		public static  File myFile = new File("fileHandling.txt");
		public static void createFile() {
		        try {
		            myFile.createNewFile();
		        } catch (IOException e) {
		            System.out.println("Unable to create this file");
		            e.printStackTrace();
		        }
		}
		public static void writeFile() {
			  try {
		            FileWriter fileWriter = new FileWriter("fileHandling.txt");
		            fileWriter.write("This is our first file from this java course\nOkay now bye");
		            fileWriter.close();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		}
		public static void  readFile() {
			 try {
		            Scanner sc = new Scanner(myFile);
		            while(sc.hasNextLine()){
		                String line = sc.nextLine();
		                System.out.println(line);
		            }
		            sc.close();
		        } catch (FileNotFoundException e) {
		            e.printStackTrace();
		        }
		}
		public static void deleteFile() {
			 if(myFile.delete()){
		            System.out.println("I have deleted: " + myFile.getName());
		        }
		        else{
		            System.out.println("Some problem occurred while deleting the file");
		        }

		}
	    public static void main(String[] args) {

	        // Code to create a new file
	    	FileHandling.createFile();
	        // Code to write to a file
	    	FileHandling.writeFile();
	    	
	        // Reading a file
	        FileHandling.writeFile();     
	        // Deleting a file
			FileHandling.deleteFile();
	    }
	}
	    
