package com.demo.componentmapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
		public static void main(String[] args) {
			//activate Connection with database
			  SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
				// Require to start session
			  Session session = factory.openSession();
		          // Transaction start
		          Transaction tx = session.beginTransaction();
		          Employee employee = new Employee();
		          employee.setName("John Doe");

		          Address address = new Address();
		          address.setStreet("123 Main St");
		          address.setCity("City");
		          address.setState("State");
		          address.setZipCode("12345");
		          employee.setAddress(address);
		          session.save(employee);
		          tx.commit();
		          session.close();
		          session = factory.openSession();
		          employee = session.get(Employee.class, 1L); // Assuming the employee ID is 1
		          // Retrieve the employee from the database
		          employee = session.get(Employee.class, 1L); // Assuming the employee ID is 1
		          if (employee != null) {
		              // Access the address component
		              Address retrievedAddress = employee.getAddress();
		              System.out.println("Street: " + retrievedAddress.getStreet());
		              System.out.println("City: " + retrievedAddress.getCity());
		              System.out.println("State: " + retrievedAddress.getState());
		              System.out.println("Zip Code: " + retrievedAddress.getZipCode());
		          } else {
		              System.out.println("Employee not found.");
		          }

		}
}
