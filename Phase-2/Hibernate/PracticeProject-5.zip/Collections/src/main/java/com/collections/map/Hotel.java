package com.collections.map;

import java.util.Map;

public class Hotel {
	private int id;
	private String name;
	private Map<String,Integer> rooms;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<String, Integer> getRooms() {
		return rooms;
	}
	public void setRooms(Map<String, Integer> rooms) {
		this.rooms = rooms;
	}
	
}
