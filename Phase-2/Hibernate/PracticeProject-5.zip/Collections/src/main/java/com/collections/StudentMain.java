package com.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentMain {
public static void main(String[] args) {
	  SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();	Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
	List<String> list1=new ArrayList<String>(); 
	list1.add("EC-121");
	list1.add("MA-131");
	list1.add("EN-141");
	 Student student1 = new Student();
     student1.setId(1);
     student1.setName("Suchit");
     student1.setBooks(list1);

     List<String> list2 = new ArrayList<String>();
     list2.add("DAA-78");
     list2.add("COA-148");
     Student student2 = new Student();
     student2.setId(2); // Assign a unique identifier
     student2.setName("Dewika Mishra");
     student2.setBooks(list2);

     session.save(student1);
     session.save(student2);
	tx.commit();
		session.close();
}
}
