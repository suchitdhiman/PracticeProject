package com.collections.map;

import java.util.HashMap;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
		 SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();	Session session=factory.openSession();
			Transaction tx=session.beginTransaction();
			HashMap<String,Integer> map1=new HashMap<String,Integer>();    
			map1.put("Hotel Prakash",302);
			map1.put("Hotel praksh",305 );
			map1.put("Hotel Prakash", 309);
			HashMap<String,Integer> map2=new HashMap<String,Integer>();    
			map2.put("Hotel Krishna", 402);
			map2.put("Hotel Krishna", 406);
			map2.put("Hotel Krishna", 409);
			Hotel hotel=new Hotel();
			hotel.setName("Hotel Krishna");
			hotel.setRooms(map1);
			Hotel hotel2=new Hotel();
			hotel2.setName("Hotel Krishna");
			hotel2.setRooms(map2);
			session.save(hotel);
			session.save(hotel2);
			tx.commit();
			session.close();
	}
}
