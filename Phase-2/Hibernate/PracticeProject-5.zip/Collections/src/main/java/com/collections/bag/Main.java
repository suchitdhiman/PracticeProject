package com.collections.bag;

import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
		public static void main(String[] args) {
			  SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();	Session session=factory.openSession();
				Transaction tx=session.beginTransaction();
				ArrayList<String> answerList1 = new ArrayList<String>();
		        answerList1.add("Object Oriented Programming language");
		        answerList1.add("Structural Programming language");
		        answerList1.add("Hybrid Programming language");
		        answerList1.add("Monolithic Programming language");
		  
		        ArrayList<String> answerList2 = new ArrayList<String>();
		        answerList2.add("User friendly Object oriented language");
		        answerList2.add("Complicated structural language");
		        answerList2.add("Functional language");
		        answerList2.add("RDBMS");
		  
		        MultipleChoiceQuestion mcq1 = new MultipleChoiceQuestion();
		        mcq1.setQuestionName("Java is");
		        mcq1.setChoices(answerList1);
		  
		        MultipleChoiceQuestion mcq2 = new MultipleChoiceQuestion();
		        mcq2.setQuestionName("Python is");
		        mcq2.setChoices(answerList2);
		  
		        session.persist(mcq1);
		        session.persist(mcq2);
			tx.commit();
				session.close();
		}
}
