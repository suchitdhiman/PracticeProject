package com.collections.bag;
import java.util.List;
public class MultipleChoiceQuestion {

	// Attributes should match
	// with 'Questions' table
	private int qId;
	private String questionName;

	// As each question may have 1 - N choices,
	// let us collect via a list here
	private List<String> choices;

	public int getqId() { return qId; }
	public void setqId(int qId) { this.qId = qId; }
	public String getQuestionName() { return questionName; }
	public void setQuestionName(String questionName)
	{
		this.questionName = questionName;
	}
	public List<String> getChoices() { return choices; }
	public void setChoices(List<String> choices)
	{
		this.choices = choices;
	}
}
