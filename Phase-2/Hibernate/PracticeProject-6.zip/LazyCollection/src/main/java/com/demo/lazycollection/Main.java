package com.demo.lazycollection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
		public static void main(String[] args) {
			 SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();	Session session=factory.openSession();
				Transaction tx=session.beginTransaction();
				 Department department = new Department();
			        department.setName("IT");

			        Employee employee1 = new Employee();
			        employee1.setName("John");
			        employee1.setDepartment(department);

			        Employee employee2 = new Employee();
			        employee2.setName("Jane");
			        employee2.setDepartment(department);

			        department.getEmployees().add(employee1);
			        department.getEmployees().add(employee2);
			        session.save(department);
			        session.save(employee1);
			        session.save(employee2);
			        department = session.get(Department.class, 1L);
			        System.out.println("Department: " + department.getName());
			        System.out.println("Employees: " + department.getEmployees().size());

				
				tx.commit();
				session.close();
		}
}
