package com.example;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	static Connection con;
	
	public static Connection getConnection() {
		//load driver in memory
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//connect database
		
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce","root","sk8006424");
	}
	catch(Exception e) {
		e.printStackTrace();
		
	}
		return con;
		
	}
	
	
	
	
	
	
	

}
