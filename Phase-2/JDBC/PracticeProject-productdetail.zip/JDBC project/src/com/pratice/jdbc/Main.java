package com.pratice.jdbc;

import java.util.Scanner; 
public class Main {
	public static Scanner sc=new Scanner(System.in);
	public static int inputException() {
		 int choice = 0;
         boolean validInput = false;
         while (!validInput) {
             System.out.print("Enter the option : ");
             String input = sc.nextLine();
             try {
            	 choice = Integer.parseInt(input);
                 validInput = true;
             } catch (NumberFormatException e) {
                 System.out.println("Invalid input. Please enter a valid integer for the book ID.");
             }
         }
         return choice;
	}
	public static void userOption() {
		System.out.println("1. Create table Book.");
		System.out.println("2. Insert Book.");
		System.out.println("3. Retrive all the Books from the database.");
		System.out.println("4. Retrive Book from the database by Book ID.");
		System.out.println("5. Close all the connctions from database.");
		run();
		}
	 public static void run() {
	        boolean exit = false;
	        int option;
	        while (!exit) {
	            option = Main.inputException();
	            switch (option) {
	                case 1:
	                  DataBaseconnection.connectionFunction();
	                    break;
	                case 2:
	                    DataBaseconnection.insertBook();
	                  userOption();
	                    break;
	                case 3:
	              DataBaseconnection.printAllBooks();
	                	userOption();
	                	break;
	                case 4:
	                   DataBaseconnection.getBookById();
	                   userOption();
	                    break;
	                case 5:
	                	DataBaseconnection.ClosedConnetion();
	                	userOption();
	                	break;
	                default:
	                    System.out.println("Invalid option. Please try again.");
	                    break;
	            }
	        }
	    }
public static void main(String[] args) {
		Main.userOption();
}
}
