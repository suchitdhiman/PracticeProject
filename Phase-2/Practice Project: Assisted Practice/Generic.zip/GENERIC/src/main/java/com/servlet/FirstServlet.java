package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
public class FirstServlet implements Servlet {

	ServletConfig config;
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("Going to destroy the servlet object.....................");
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		this.config=config;
		System.out.println("Creating Servlet Object...........");
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Servicing...........");
		PrintWriter out=res.getWriter();
		out.print("<html><body>");
        out.print("<h2>Welcome to GeeksForGeeks</h2>");
        out.print("</body></html>");

        
	}

}
