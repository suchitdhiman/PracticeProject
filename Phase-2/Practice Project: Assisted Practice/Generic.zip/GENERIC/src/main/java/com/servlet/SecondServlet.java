package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class SecondServlet  extends GenericServlet{

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("This is Servlet using Generic Servlet ...........");
		PrintWriter out=arg1.getWriter();
		String name=arg0.getParameter("name");
		System.out.println(name);
		out.println("<H1>");
		out.println("This is Generic Servlet");
		out.println("</h1>");
	}

}
