package com.methodinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormServlet
 */
@WebServlet("/FormServlet")
public class FormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public FormServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		String name=request.getParameter("name");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<html><body>");
		out.println("<h2>Get method result :</h2>");
		out.println("<p>Name :"+name+"</p>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		   String email = request.getParameter("email");

	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println("<h2>POST Method Result:</h2>");
	        out.println("<p>Email: " + email + "</p>");
	        out.println("</body></html>");
	}

}
//
//The key difference between GET and POST methods in this example is the way data is transmitted.
//In the GET method, the username and password values are appended to the URL as query parameters,
//visible in the browser's address bar. However, in the POST method, the data is sent in the body
//of the HTTP request, making it not visible in the URL.

//It's important to note that for sensitive data such as passwords, it's generally recommended to 
//use the POST method to ensure that the data is not exposed in the URL or in the browser's history.
