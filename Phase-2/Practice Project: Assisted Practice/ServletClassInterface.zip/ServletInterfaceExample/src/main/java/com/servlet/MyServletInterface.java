package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public interface MyServletInterface {
    void init() throws ServletException;
    void service(ServletRequest request, ServletResponse response) throws ServletException, IOException;
    void destroy();
}