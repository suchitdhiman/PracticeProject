package com.servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

public class ServletContainer {
    public static void main(String[] args) throws ServletException, IOException {
        MyServletInterface servlet = new MyServlet();

        servlet.init();

        ServletRequest request = null; // Simulated request object
        ServletResponse response = null; // Simulated response object
        servlet.service(request, response);

        servlet.destroy();
    }
}
