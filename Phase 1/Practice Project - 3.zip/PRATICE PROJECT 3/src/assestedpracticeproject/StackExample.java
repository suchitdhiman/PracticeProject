package assestedpracticeproject;

import java.util.Stack;

public class StackExample {

	
	public static void main(String[] args) {
		Stack<Integer> stack=new Stack();
		// add element to the stack
		stack.add(10);
		stack.add(20);
		stack.add(30);
		stack.add(40);
		stack.add(50);
		stack.add(60);
		System.out.println("Stack Element "+ stack);
		// removing element form the stack
		stack.pop();
		System.out.println("Update stack Element "+stack);
	}
}
