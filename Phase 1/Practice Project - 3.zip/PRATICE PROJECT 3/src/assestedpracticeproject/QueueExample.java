package assestedpracticeproject;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
	 public static void main(String[] args) {
	        // Create a queue using LinkedList
	        Queue<Integer> queue = new LinkedList<>();

	        // Insert elements into the queue using offer() method
	        queue.add(10);
	        queue.add(20);
	        queue.add(34);
	        queue.add(40);
	        queue.add(50);

	        System.out.println("Queue elements: " + queue);

	        // Remove and retrieve the head of the queue using poll() method
	        int removedElement = queue.poll();
	        System.out.println("Removed element: " + removedElement);
	        System.out.println("Updated Queue elements: " + queue);
	 }
}
	 
