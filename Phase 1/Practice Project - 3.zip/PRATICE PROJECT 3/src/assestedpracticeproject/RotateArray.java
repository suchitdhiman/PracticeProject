package assestedpracticeproject;

public class RotateArray {
	public static int[] RightRotate(int[] arr) {
		int temp=arr[arr.length-1];
		int i=0;
		for( i=arr.length-1;i>0;i--) {
			arr[i]=arr[i-1];
		}
		arr[0]=temp;
		return arr;
	}
	public static void print(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
public static void main(String[] args) {
	int array[] = { 11, 22, 33, 44, 55, 66, 77 };   
	 int[] ansArray= RotateArray.RightRotate(array);
	 RotateArray.print(ansArray);
}
}
