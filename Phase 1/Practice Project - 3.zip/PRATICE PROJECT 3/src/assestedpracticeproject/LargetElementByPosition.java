package assestedpracticeproject;

import java.util.PriorityQueue;

public class LargetElementByPosition {
		public static int fourthLargestElement(int[] arr) {
			PriorityQueue<Integer>pq=new PriorityQueue<>();
			for(int i=0;i<arr.length;i++) {
				pq.add(arr[i]);
				if(pq.size()>4)
					pq.poll();
			}
			return pq.poll();
		}
	
	public static void main(String[] args) {
		int array[] = { 11, 22, 33, 44, 55, 66, 77 }; 
		System.out.println(LargetElementByPosition.fourthLargestElement(array));
		
	}
}
