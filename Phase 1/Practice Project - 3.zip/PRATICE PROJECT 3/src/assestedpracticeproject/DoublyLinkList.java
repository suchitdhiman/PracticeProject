package assestedpracticeproject;

import java.util.Scanner;

class DoublyNode{
	DoublyNode pre;
	int data;
	DoublyNode next;
public DoublyNode(int data) {
	// TODO Auto-generated constructor stub
	this.data=data;
	this.pre=null;
	this.next=null;
}	
}
public class DoublyLinkList {
	DoublyNode head;	
	public DoublyLinkList() {
		// TODO Auto-generated constructor stub
	this.head=null;
	}
	public void insert(int data) {
		DoublyNode dn=new DoublyNode(data);
		if(head==null) {
			head=dn;
		}
		else {
			DoublyNode temp=head;
			while(temp.next!=null)
				temp=temp.next;
		temp.next=dn;
		dn.pre=temp;
		}
	}
	public void forwardTraverse() {
		if(head==null)
			System.out.println("list is Empty....!!!!!!");
	else {
		System.out.println("Forward Traverse :");	
		DoublyNode temp=head;
		while(temp!=null) {
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
	}
		System.out.println();
	}
	public void backwardTraverse() {
		if(head==null) {
			System.out.println("listis Empty");
		}
		else {
			System.out.println("Backward Traverse :");
			DoublyNode temp=head;
		while(temp.next!=null)
			temp=temp.next;
		DoublyNode moveBack=temp;
		while(moveBack!=null) {
			System.out.print(moveBack.data+" ");
			moveBack=moveBack.pre;
		}
		}
		System.out.println();
		}
	public static void main(String[] args) {
		 DoublyLinkList list=new DoublyLinkList();
		 list.insert(10);
	        list.insert(20);
	        list.insert(30);
	        list.insert(40);
	        list.insert(50);
	  
	        list.forwardTraverse();
	        list.backwardTraverse();
	}
}
