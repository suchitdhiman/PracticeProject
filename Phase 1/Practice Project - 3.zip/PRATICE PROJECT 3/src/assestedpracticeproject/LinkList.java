package assestedpracticeproject;

import java.util.Scanner;

class Node{
	int data;
	Node next;
	public Node(int data) {
		// TODO Auto-generated constructor stub
		this.data=data;
		this.next=null;
	}
}
public class LinkList {
		Node head;
	public  LinkList() {
		// TODO Auto-generated constructor stub
		this.head=null;
	}
	public  void insert(int data) {
		Node newNode=new Node(data);
		if(head==null) {
			head=newNode;
		}
		else {
			Node temp=head;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=newNode;
		}
	}
	public void deleteFirstOccurance(int key) {
		if(head==null) {
			System.out.println("list is empty.....!!!!!");
		}
		else {
			Node temp=head;
			while(temp.next.data!=key || temp.next.next==null) {
				temp=temp.next;
			}
			if(temp.next.data==key) {
				temp.next=temp.next.next;
			}
		}
	}
	void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
	}
		 public static void main(String[] args) {
		        LinkList list = new LinkList();
		        Scanner sc=new Scanner(System.in);
		        System.out.println("Enter the number of element you want Insert");
		        int n=sc.nextInt();
		        for(int i=0;i<n;i++) {
		        list.insert(sc.nextInt());	
		        }
		        System.out.print("Original List: ");
		        list.display();
		        System.out.println("Enter the Key you want to delete from the list ");
		        int key=sc.nextInt();
		        list.deleteFirstOccurance(key);
		        System.out.print("List after deleting first occurrence of " + key + ": ");
		        list.display();
		        sc.close();
	}
}
