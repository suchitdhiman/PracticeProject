package assestedpracticeproject;

import java.util.Scanner;

class CircularNode{
	int data;
	CircularNode next;
	public CircularNode(int data) {
		// TODO Auto-generated constructor stub
		this.data=data;
		this.next=null;
	}
}
public class CircularLinkList {
		CircularNode head;
		public   void insert(int data) {
			CircularNode cn=new CircularNode(data);
			if(head==null) {
				head=cn;
				cn.next=cn;
			}
			else if (data < head.data) {
				CircularNode temp=head;
	            // Insert at the beginning if the new element is smaller than the head
				while (temp.next != head)
	                temp = temp.next;
	  
	            temp.next = cn;
	            cn.next = head;
	            head = cn;
	        }
			else {
				  // Insert at the middle if the new element is smaller than the any node
				CircularNode temp=head;
				while(temp.next!=head && temp.next.data<data) {
					temp=temp.next;
				}
				cn.next=temp.next;
				temp.next=cn;
			}
		}
		  public  void display() {
		        if (head == null) {
		            System.out.println("List is empty.");
		            return;
		        }

		        CircularNode current = head;
		        do {
		            System.out.print(current.data + " ");
		            current = current.next;
		        } while (current != head);
		        System.out.println();
		    }
		  public static void main(String[] args) {
			  CircularLinkList list = new CircularLinkList();
		        Scanner sc=new Scanner(System.in);
		        System.out.println("Enter the number of element you want Insert");
		        int n=sc.nextInt();

		        for(int i=0;i<n;i++) {
		        list.insert(sc.nextInt());
		        }
		        System.out.print("Original List: ");
		        list.display();
		        int newElement=sc.nextInt();
		        list.insert(newElement);
		        System.out.println("After inserting new Element :");
		        list.display();
		}
}
