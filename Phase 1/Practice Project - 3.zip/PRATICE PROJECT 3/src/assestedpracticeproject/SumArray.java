package assestedpracticeproject;

public class SumArray {
	
	public static int findSumBetweenRange(int[] arr,int s,int e ) {
		int sum=0;
		for(int i=0;i<arr.length;i++) {
			if(i>=s && i<=e)
				sum+=arr[i];
		}
		return sum;
	}
	public static void main(String[] args) {
		int array[] = { 11, 22, 33, 44, 55, 66, 77 }; 
		System.out.println(SumArray.findSumBetweenRange(array, 2, 4));
	}
}
