package search;

public class ExponentialSearch {

    public static int exponentialSearch(int[] arr, int element) {
        if (arr[0] == element) {
            return 0;
        }
        int i = 1;
        while (i < arr.length && arr[i] <= element) {
            i *= 2;
        }
       
        int low = i / 2;
        int high = Math.min(i, arr.length - 1);

        return binarySearch(arr, element, low, high);
    }

    public static int binarySearch(int[] arr, int target, int low, int high) {
        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) {
                return mid; 
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1; 
    }

    public static void main(String[] args) {
        int[] numbers = {12, 20, 23, 24, 25, 26, 28, 29};
        int element = 25;

        int index = exponentialSearch(numbers, element);

        if (index != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found");
        }
    }
}