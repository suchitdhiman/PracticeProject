package search;

public class LinearSearch {
	public static int linearSearch(int arr[],int element) {
		for(int i = 0; i< arr.length; i++) {
			if(arr[i]== element) {
				return i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {12, 20, 23, 24, 25, 26, 28, 29};
		int element = 24;
		int index = linearSearch(arr, element);
		
		if (index != -1) {
			System.out.println("Element found at Index: "+index);
		}
		else {
			System.out.println("Element not Found");
		}
		
		
		

	}

}

