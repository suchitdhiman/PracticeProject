package search;

public class BinarySearch {
	public static int binearySearch(int arr[], int element) {
		int start=0,end=arr.length-1;
        while(start<=end){
            int mid=(start+end)/2;
            if(arr[mid]==element)
            return mid;
            if(arr[mid]>element)
            end=mid-1;
            else
            start=mid+1;
        }
        return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {12, 20, 23, 24, 25, 26, 28, 29};
		int element = 26;
		int index = binearySearch(arr, element);
		
		if (index != -1) {
			System.out.println("Element found at Index: "+index);
		}
		else {
			System.out.println("Element not Found");
		}

	}

}
