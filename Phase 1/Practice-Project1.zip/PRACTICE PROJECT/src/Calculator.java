
public class Calculator {
    private double num1;
    private double num2;
    private double sum;
    
    public Calculator(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    
    public double getNum1() {
        return num1;
    }
    
    public void setNum1(double num1) {
        this.num1 = num1;
    }
    
    public double getNum2() {
        return num2;
    }
    
    public void setNum2(double num2) {
        this.num2 = num2;
    }
    
    
    public void setSum(double sum) {
        this.sum = sum;
    }
    
    public double addition() {
        this.sum = this.num1 + this.num2;
        return this.sum;
    }
    
    public double subtraction() {
        this.sum = this.num1 - this.num2;
        return this.sum;
    }
    
    public double multiplication() {
        sum = num1 * num2;
        return this.sum;
    }
    
    public double division() {
        if (num2 != 0) {
            sum = num1 / num2;
            
        } else {
            System.out.println("Error: Division by zero is not allowed.");
        }
        return this.sum;
    }
}