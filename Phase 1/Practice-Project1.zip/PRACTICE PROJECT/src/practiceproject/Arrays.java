package practiceproject;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//array of Strings
		 String[] strings= {"Suchit", "Shashant","Shubham"};
		        // array of integers
		        int[] numbers = new int[5];
		        

		        // Initialization of array elements
		        for (int i = 0; i < numbers.length; i++) {
		            numbers[i] = i + 1;
		        }

		        // Modify array elements
		        numbers[2] = 10;
		        numbers[4] = 20;

		        // Accessing array elements
		        for (int i = 0; i < numbers.length; i++) {
		            System.out.println("Element at index " + i + ": " + numbers[i]);
		        }
		            // String Array
		            for (int i = 0; i < strings.length; i++) {
			            System.out.println("Element at index " + i + ": " + strings[i]);
		        }
		    }


	}


