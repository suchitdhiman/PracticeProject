package practiceproject;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {

	public static void main(String[] args) {
		        String regex = "^[a-zA-Z0-9]+$";
		        String input = "HelloWorld123";
		        String input2= "SuchitKumar*";
		        Pattern pattern = Pattern.compile(regex);
		        Matcher matcher = pattern.matcher(input);
		        if (matcher.matches()) {
		            System.out.println("Match found!");
		        } else {
		            System.out.println("Match not found!");
		        }
		        Matcher matcher2 = pattern.matcher(input2);
		        if (matcher2.matches()) {
		            System.out.println("Match found!");
		        } else {
		            System.out.println("Match not found!");
		        }

	}

}
