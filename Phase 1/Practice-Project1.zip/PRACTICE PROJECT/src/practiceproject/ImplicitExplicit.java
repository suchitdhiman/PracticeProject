package practiceproject;

public class ImplicitExplicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char temp = 'a';
		System.out.println(temp);
		short num = (short)temp;
		System.out.println(num);
		// implicit
		int num2 = num;
		System.out.println(num2);
		long num3= num2;
		System.out.println(num3);
		float num4 = num3;
		System.out.println(num4);
		double num5 = num4;
		System.out.println(num5);
		
		//explicit
		float num6 = (float)num5;
		System.out.println(num6);
		
		long num7 = (long)num6;
		System.out.println(num7);
		
		int num8 = (int) num7;
		System.out.println(num8);
		
		short num9 = (short) num8;
		System.out.println(num9);
		
		char temp2 = (char) num9;
		System.out.println(temp2);
		
		 System.out.println(Parent.publicVariable);
		 System.out.println(Parent.protectedVariable);

	}

}
