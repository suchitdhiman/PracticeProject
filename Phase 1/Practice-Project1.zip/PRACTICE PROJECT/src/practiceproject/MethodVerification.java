package practiceproject;

public class MethodVerification {
	    public static void main(String[] args) {
	        // Verify implementations of methods
	        verifyMethod1();
	        verifyMethod2();
	        // calling a method
	        callMethod1();
	        callMethod2();
	    }
	    // Method to Add two numbers
	    public static int add(int a, int b) {
	        return a + b;
	    }
	    // Method to Check if a string is empty
	    public static boolean isEmpty(String str) {
	        return str == null || str.isEmpty();
	    }
	    // Verify implementation of Method 1
	    public static void verifyMethod1() {
	        int result = add(5, 10);
	        if (result == 15) {
	            System.out.println("Method 1 implemented");
	        } else {
	            System.out.println("Method 1 not implemented");
	        }
	    }
	    // Verify implementation of Method 2
	    public static void verifyMethod2() {
	        boolean result = isEmpty("");
	        if (result) {
	            System.out.println("Method 2 implemented");
	        } else {
	            System.out.println("Method 2 not implemented");
	        }
	    }
	    // Call Method 1
	    public static void callMethod1() {
	        int result = add(3, 7);
	        System.out.println("Result of Method 1: " + result);
	    }
	    // Call Method 2
	    public static void callMethod2() {
	        boolean result = isEmpty("Hello");
	        System.out.println("Result of Method 2: " + result);
	    }
	}
