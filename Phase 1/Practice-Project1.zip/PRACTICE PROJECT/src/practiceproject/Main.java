package practiceproject;

class Company {
	  String employee_name;

	  // default constructor
	  public Company() {
	    employee_name = "Suchit";
	  }
	  // parameter constructor
	  public Company(String name) {
		  this.employee_name=name;
	  }
	}

	public class Main {
	  public static void main(String[] args) {

	    // object is created in another class
	    Company obj = new Company();
	    Company obj2=new Company("Ram");
	    System.out.println("Employee name = " + obj.employee_name);
	    System.out.println("Employee name = " + obj2.employee_name);
	  }
	}
