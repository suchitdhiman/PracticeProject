package practiceproject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class CollectionImplementation  {
	
	public static void main(String[] args) {
		
    ArrayList<String> list = new ArrayList<String>();
    list.add("I");
    list.add("am");
    list.add("working");
    list.add("hard ");
    System.out.println(list.size());
    // it checks weather list contains particular element or not . return true or false 
    System.out.println(list.contains("hard "));
    // it return the which present at particular index
    System.out.println(list.get(0));
    // iterator use the iterate over the list
    Iterator itr = list.iterator();
    while (itr.hasNext()) {
        System.out.println(itr.next());
    }
  Collections.reverse(list);
  System.out.println(list.toString());
  Set<String> set=new HashSet<>(list);
 System.out.println(set);
	}
}
