package practiceproject;

//Parent class
  class Parent {
	int deafult =0;
 public static int publicVariable = 10;
 private int privateVariable = 20;
 protected static int protectedVariable = 30;

 public void publicMethod() {
     System.out.println("This is a public method.");
 }

 private void privateMethod() {
     System.out.println("This is a private method.");
 }

 protected void protectedMethod() {
     System.out.println("This is a protected method.");
 }

 void defaultMethod() {
     System.out.println("This is a default method.");
 }
}

//Child class
class Child extends Parent {
 public void childMethod() {
     System.out.println("This is a method in the child class.");
//     Accessing parent variables
     System.out.println("publicVariable: " + publicVariable);
     System.out.println("protectedVariable: " + protectedVariable);
     // Private variable cannot be accessed in the child class

//     Accessing parent's methods
     publicMethod();
     protectedMethod();
     // Private method cannot be accessed in the child class
 }
}
public class AccessModifier  {
 public static void main(String[] args) {
     Parent parent = new Parent(); 
     System.out.println("Accessing parent's variables:");
     System.out.println("publicVariable: " + parent.publicVariable);
     System.out.println(Parent.protectedVariable);
     System.out.println(parent.publicVariable);
     // Private and protected variables cannot be accessed outside the class

     System.out.println("Accessing parent's methods:");
     parent.publicMethod();
     // Private and protected methods cannot be accessed outside the class

     Child child = new Child();
     child.childMethod();
 }
}