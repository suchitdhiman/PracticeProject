package practiceproject;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
//import java.util.*;
public class MapImplimentation {
	
	    public static void main(String[] args) {
	        //Instance of the map implementation
	        Map<Integer, String> map = new HashMap<>();

	        // Test the put operation
	        map.put(1,"one");
	        map.put(2,"two");
	        map.put(3,"three");

	        //Get operation
	        String value = map.get("two");
	        System.out.println("Value of 2: " + value);

	        //size operation
	        int size = map.size();
	        System.out.println("Map size: " + size);

	        //containsKey operation
	        boolean containsKey = map.containsKey("three");
	        System.out.println("Contains 'three': " + containsKey);

	        // remove operation
	        String removedValue = map.remove(1);
	        System.out.println("Removed value of 'one': " + removedValue);

	        // keySet operation
	        Set<Integer> keySet = map.keySet();
	        System.out.println("Keys in the map: " + keySet);

	        // values operation
	        Collection<String> values = map.values();
	        System.out.println("Values in the map: " + values);

	        // entrySet operation
	        Set<Entry<Integer, String>> entrySet = map.entrySet();
	        for (Entry<Integer, String> entry : entrySet) {
	            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
	        }
	    }
	}

