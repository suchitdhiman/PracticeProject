package practiceproject;
	public class InnerClassVerification {
	    private int outerVariable = 10;
	    // Inner class
	    public class Inner {
	     public void display() {
	       System.out.println("Value of outerVariable: " + outerVariable);
	        }
	    }
	    public static void main(String[] args) {
	      // instance of the outer class
	     InnerClassVerification outer = new InnerClassVerification();
	       // instance of the inner class
	      InnerClassVerification.Inner inner = outer.new Inner();
	      //display method of the inner class
	      inner.display();
	    }
	}
