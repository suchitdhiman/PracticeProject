package practiceproject;

public class StringConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		     
		        String str = "Suchit, Kumar";
		        // StringBuffer
		        StringBuffer stringBuffer = new StringBuffer(str);
		        // StringBuilder
		        StringBuilder stringBuilder = new StringBuilder(str);
	
		        System.out.println("StringBuffer: " + stringBuffer);
		        System.out.println("StringBuilder: " + stringBuilder);
		    }
		}
