import java.util.regex.*;
import java.util.*;
public class EmailCheck {
	public static boolean emailValidation(String email) {
		if(email==null) {
			return false;
		}
		 //Regular Expression
		String emailRegex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$"; 
		Pattern pattern = Pattern.compile(emailRegex);
        if (pattern .matcher(email).matches())	{
        	return true;}
        else {
        	return false;
        }
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner su = new Scanner(System.in); 
		System.out.print("Enter yout email: ");
		
		String email= su.nextLine();
		System.out.println("Email entered= "+ emailValidation(email));
		

	}

}
