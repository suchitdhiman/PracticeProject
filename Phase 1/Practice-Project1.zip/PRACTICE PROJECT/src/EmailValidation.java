import java.util.Scanner;
public class EmailValidation {
    public static void main(String[] args) {
        String[] emails = {"suchit@gmail.com", 
        		"maan@yahoo.com", 
        		"juss@outlook.com", 
        		"devi@bing.com", 
        		"evish@msn.com"};
        //scanner object to get user input
        Scanner su= new Scanner(System.in);
        System.out.println("Enter an email ID to search: ");
  
        String inputEmail = su.nextLine();
        
        // boolean variable to indicate if the input is found or not
        boolean valid = false;
        
        for (String email : emails) {
            if (inputEmail.equals(email)) {
                valid = true;
                break;
            }
        }
        if (valid) {
            System.out.println("Email ID " + inputEmail + " is valid.");
        } else {
            System.out.println("Email ID " + inputEmail + " is not valid.");
        }
    }
}