import java.util.Scanner;

public class CalculatorUsingSwitch {

    public static void main(String[] args) {
        // scanner object to get user input
        Scanner su = new Scanner(System.in);
        
        // Take input from user
        System.out.println("Enter the first number: ");
        double num1 = su.nextDouble();
        System.out.println("Enter the second number:");
        double num2 = su.nextDouble();
        
        // Take operator from user
        System.out.println("Enter an operator (+, -, *, /): ");
        char operator = su.next().charAt(0);
        
        
        // variable to store the sum
        double sum;
        
        // calculation based on the operator using a switch.
        switch (operator) {
            case '+':
                sum = num1 + num2;
                break;
            case '-':
                sum = num1 - num2;
                break;
            case '*':
                sum = num1 * num2;
                break;
            case '/':
                // Check if the second number is zero and handle the exception
                if (num2 == 0) {
                    throw new ArithmeticException("Cannot divide by zero");
                }
                sum = num1 / num2;
                break;
            default:
                // Handle the invalid operator case
                throw new IllegalArgumentException("Invalid operator");
        }
        
        // Display the result
        System.out.println(num1 + " " + operator + " " + num2 + " = " + sum);
    }
}