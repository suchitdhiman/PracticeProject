import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
    	// scanner object to get user input
        Scanner su = new Scanner(System.in);
        
        // Take input from user
        System.out.print("Enter the first number: ");
        double num1 = su.nextDouble();
        System.out.print("Enter the second number:");
        double num2 = su.nextDouble();
        // Take operator from user
        System.out.println("Enter an operator (+, -, *, /): ");
        char operator = su.next().charAt(0);
        Calculator calculator = new Calculator(num1,num2);
        
        // variable to store the sum
        switch (operator) {
        case '+':
        	System.out.println("Addition: " + calculator.addition());
            break;
        case '-':
        	System.out.println("Subtraction: " + calculator.subtraction());
            break;
        case '*':
        	System.out.println("Multiplication: " + calculator.multiplication());
            break;
        case '/':
            System.out.println("Division: " + calculator.division());
            break;  
    }   
            }
}