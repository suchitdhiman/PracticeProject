package com.vaccine.repo;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vaccine.entity.VaccinationCenter;

@Repository
public interface VaccineCenterRepo extends CrudRepository<VaccinationCenter , Long>{

}
