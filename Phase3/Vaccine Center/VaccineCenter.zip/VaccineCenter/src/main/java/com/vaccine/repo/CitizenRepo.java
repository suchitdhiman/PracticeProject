package com.vaccine.repo;

import org.springframework.data.repository.CrudRepository;

import com.vaccine.entity.Citizen;

public interface CitizenRepo  extends CrudRepository<Citizen, Long>{

	 

}
