package com.vaccine.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.vaccine.entity.*;
import com.vaccine.entity.VaccinationCenter;
import com.vaccine.service.VaccineService;

@Controller
public class vaccineController {

	@Autowired 
	VaccineService service;
	
	@GetMapping("/")
	public String homePage() {
		return "login";
	}
	@GetMapping("/logout")
	public String logout() {
		return "login";
	}
	@GetMapping("/welcome")
	public String homePage1(Model model) {
		ArrayList<VaccinationCenter> centerList=service.getAllCenter();
		model.addAttribute("centerLsit" ,centerList);
		return "vaccinecenter";
	}
	@GetMapping("/admin-registration")
	public String register(@ModelAttribute("user") User user) {
		return "registration";
	}
	@PostMapping("/register")
	public String processRegistrationForm(@ModelAttribute("user") User user) {
		System.out.println(user);
		service.save(user);
		return "registration-success";
	}
	
	@PostMapping("/login")
	public String vaccineCenter(@RequestParam("username") String username,
            @RequestParam("password") String password, Model model ) {
	User temp=service.loadUserByUsername(username);
	if( temp!=null && temp.getPassword().equals(password)  ) {
		ArrayList<VaccinationCenter> centerList=service.getAllCenter();
		model.addAttribute("centerLsit" ,centerList);
		return  "vaccinecenter";
	}
	else {
		System.out.println("home page");
		model.addAttribute( "msg" , "Invalid username and password!!!!!");
		return "login";
	}
	}
	@GetMapping("/addcenter")
	public String addCenter() {
		return "newvaccinecenter";
	}
	@PostMapping("/add-center")
	public String addCenterProcess(@ModelAttribute("center") VaccinationCenter center) {
		service.SaveCenter(center);
		System.out.println(center);
		return "centeradded";
	}
	@GetMapping("/citizen")
	public String citize(Model model) {
		ArrayList<Citizen> citizenList=service.getAllcitizen();
		model.addAttribute("citizenList",citizenList);
		return "citizen";
	}
	@GetMapping("/addcitizen")
	public String addCititzen(Model model) {
		 model.addAttribute("citizen", new Citizen());
		 model.addAttribute("msg" , "Add New Citizen");
		return "addCitizen";
	}
	@PostMapping("/add-citizen")
	public String addCititzenProcess(@ModelAttribute("citizen") Citizen citizen  ,Model model  ) {
		System.out.println(citizen);
		service.saveCitize(citizen);
		ArrayList<Citizen> citizenList=service.getAllcitizen();
		model.addAttribute("citizenList",citizenList);
		return "citizen";
	}
	  @GetMapping("/view-citizen/{id}")
	public String viewDetail(@PathVariable("id") Long citizenId, Model model) {
		System.out.println("cirtizen info page ");
		  Citizen citizen =service.getCitizenById(citizenId);
		  model.addAttribute("citizen",citizen);
		return "citizenInfo";
	}
	  @GetMapping("/delete-citizen/{id}")
	    public String deleteCitizen(@PathVariable("id") Long id) {
	        service.deleteCitizenById(id);
	        return "redirect:/citizen"; // Redirect back to the citizen list page
	    }
	  @GetMapping("/delete-center/{id}")
	    public String deleteCenter(@PathVariable("id") Long id) {
	        service.deleteCenterById(id);
	        return "redirect:/citizen"; // Redirect back to the citizen list page
	    }
	  @GetMapping("/edit-citizen/{id}")
	    public String editCitizen(@PathVariable("id") Long id, Model model) {
		  Citizen citizen =service.getCitizenById(id);
		  System.out.println("edit-page");
		  model.addAttribute("citizen",citizen);
		  model.addAttribute("msg", "Edit Citizen");
	        return "addCitizen"; // Redirect back to the citizen list page
	    }
	  @GetMapping("/view-center/{id}")
		public String viewCenterDetail(@PathVariable("id") Long citizenId, Model model) {
			System.out.println("cirtizen info page ");
			  VaccinationCenter center =service.getCenterById(citizenId);
			  model.addAttribute("citizen",center);
			return "citizenInfo";
		}
}
