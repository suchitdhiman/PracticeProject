package com.vaccine.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccine.entity.Citizen;
import com.vaccine.entity.User;
import com.vaccine.entity.VaccinationCenter;
import com.vaccine.repo.CitizenRepo;
import com.vaccine.repo.VaccineCenterRepo;
import com.vaccine.repo.VaccineRepo;

@Service
public class VaccineService {

	@Autowired 
	CitizenRepo citizenRepo;
	@Autowired
	VaccineCenterRepo centerRepo;
     @Autowired 
     VaccineRepo repo;
     
     public void save(User user) {
    	 repo.save(user);
     }
     
     public User loadUserByUsername(String username){
        return  repo.findByUsername(username); 
     }

     public List<User> findAllUsers() {
    	    List<User> users = (List<User>) repo.findAll();
    	    return users.stream()
    	            .map(this::mapToUserDto)
    	            .collect(Collectors.toList());
    	}
     private User mapToUserDto(User user) {
    	    User userDto = new User();
    	    userDto.setUserId(user.getUserId());
    	    userDto.setUsername(user.getUsername());
    	    // Set other fields as needed
    	    return userDto;
    	}
     public void SaveCenter(VaccinationCenter center) {
    	 	centerRepo.save(center);
     }
     public ArrayList<VaccinationCenter > getAllCenter(){
    	 return (ArrayList<VaccinationCenter>) centerRepo.findAll();
     }
     public void saveCitize(Citizen citizen) {
    	 citizenRepo.save(citizen);
     }
     public ArrayList<Citizen> getAllcitizen(){
    	 return  (ArrayList<Citizen>) citizenRepo.findAll();
     }
     public Citizen getCitizenById(Long id) {
         return citizenRepo.findById(id).orElse(null);
     }
     public void deleteCitizenById(Long id) {
         citizenRepo.deleteById(id);
     }
     public void deleteCenterById(Long id) {
         centerRepo.deleteById(id);
     }
     public VaccinationCenter getCenterById(Long id) {
    	return  centerRepo.findById(id).orElse(null);
     }
}
