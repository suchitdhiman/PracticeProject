package com.vaccine.entity;


import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "vaccination_status")
public class VaccinationStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long statusId;

    @OneToOne
    @JoinColumn(name = "citizen_id", referencedColumnName = "citizenId")
    private Citizen citizen;

    @Column(nullable = false)
    private int numberOfVaccinations;

    private LocalDate vaccinationDate;

	public Long getStatusId() {
		return statusId;
	}

	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	public Citizen getCitizen() {
		return citizen;
	}

	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}

	public int getNumberOfVaccinations() {
		return numberOfVaccinations;
	}

	public void setNumberOfVaccinations(int numberOfVaccinations) {
		this.numberOfVaccinations = numberOfVaccinations;
	}

	public LocalDate getVaccinationDate() {
		return vaccinationDate;
	}

	public void setVaccinationDate(LocalDate vaccinationDate) {
		this.vaccinationDate = vaccinationDate;
	}

    // Getters and setters, constructors, and other methods
}
