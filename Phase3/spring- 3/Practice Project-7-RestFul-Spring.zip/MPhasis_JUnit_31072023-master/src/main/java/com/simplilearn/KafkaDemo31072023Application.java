package com.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaDemo31072023Application {

	public static void main(String[] args) {
		SpringApplication.run(KafkaDemo31072023Application.class, args);
	}

}
