import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-greeting-component',
  templateUrl: './greeting-component.component.html',
  styleUrls: ['./greeting-component.component.css']
})
export class GreetingComponentComponent implements OnInit {
  ngOnInit(): void{

  }
 
  name:string = "suchit";
  constructor(){}
  greet():void{
    alert("Hello every one, i am "+ this.name);
  }

  productList: Array<any>=[
    {pname:"Rice", price: 120},
    {pname:"Sugar", price:40}
  ]
  show:boolean = true;
}
