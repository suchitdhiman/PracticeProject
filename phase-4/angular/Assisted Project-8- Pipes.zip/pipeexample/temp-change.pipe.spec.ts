import { TempChangePipe } from './temp-change.pipe';

describe('TempChangePipe', () => {
  it('create an instance', () => {
    const pipe = new TempChangePipe();
    expect(pipe).toBeTruthy();
  });
});
