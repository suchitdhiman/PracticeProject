import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
ngOnInit(): void {
  
}


constructor(private route: Router, private us:UserService ){}

onSubmit(user:any){
console.log(user)
  this.us.validateUser(user.name)
  .subscribe(resp=>{
    if(resp.length>0){
      let obj = resp[0]
      if(obj.password === user.password){
        //cookies
        sessionStorage.setItem('username',user.name)
        this.route.navigate(['/profile']);
      }
      else{
        alert('Invalid Username')
      }
    }
      else
        alert('username doesnot here')
  })
  }
}