import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

// ds = new DemoService()
export class DemoService {

  message:string

  constructor() {
    console.log('demo service constructor!!');
    
    
    this.message='message from service';
   }
}
