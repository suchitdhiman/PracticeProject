import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';

import { ApiService } from '../shared/api.service';
import { EmployeeModel } from './employee-dashboard.model';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent  implements OnInit {
 formValue!: FormGroup; 
 employeedata!: any;
 showAdd!:boolean;
 showUpdate!:boolean;
 employeeModelobj: EmployeeModel=new EmployeeModel();
  
 constructor(private formbuilder: FormBuilder,private api:ApiService){

 }
 
 
  ngOnInit(): void {
    this.formValue=this.formbuilder.group({
      firstname:[''],
      lastname:[''],
      email:[''],
      mobile:[''],
      salary:[''],
    })
    this.getallemployee();
  }

clickAddEmployee() {
this.formValue.reset();
this.showAdd=true;
this.showUpdate=false;

}

postEmployeeDetails(){
this.employeeModelobj.firstName=this.formValue.value.firstname;
this.employeeModelobj.lastName=this.formValue.value.lastname;
this.employeeModelobj.email=this.formValue.value.email;
this.employeeModelobj.mobile=this.formValue.value.mobile;
this.employeeModelobj.salary=this.formValue.value.salary;
//passing data in post method which we have created in api service
this.api.postEmployee(this.employeeModelobj)
.subscribe(res=>{

  console.log(res)
  alert("Employee Added Succesfully")
  let ref= document.getElementById("cancel")
  ref?.click();
  this.formValue.reset();
  this.getallemployee();
},err=>{
  alert("Something went wrong")
}

)

}

getallemployee() {
this.api.getEmployee()
.subscribe(res=>{
this.employeedata=res;

})

}

deleteEmployee(row:any) {
  this.api.deleteEmployee(row.id)
  .subscribe(res=>{
    alert("Employees deleted");
    this.getallemployee();
  })
}


onEdit(row:any) {
  this.showAdd=false;
  this.showUpdate=true;
  this.employeeModelobj.id=row.id;
  this.formValue.controls['firstname'].setValue(row.firstname);
  this.formValue.controls['lastname'].setValue(row.lastname);
  this.formValue.controls['email'].setValue(row.email);
  this.formValue.controls['mobile'].setValue(row.mobile);
  this.formValue.controls['salary'].setValue(row.salary);
  
}
updateEmployeeDetails(){
  this.employeeModelobj.firstName=this.formValue.value.firstname;
this.employeeModelobj.lastName=this.formValue.value.lastname;
this.employeeModelobj.email=this.formValue.value.email;
this.employeeModelobj.mobile=this.formValue.value.mobile;
this.employeeModelobj.salary=this.formValue.value.salary;
this.api.updateEmployee(this.employeeModelobj,this.employeeModelobj.id)
.subscribe(result => {
alert("updated successfully")
let ref= document.getElementById("cancel")
  ref?.click();
  this.formValue.reset();
  this.getallemployee();

})
}
}