import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { SignupComponent } from './signup/signup.component';





const routes: Routes = [
  {path:'',redirectTo:'login', pathMatch:'full'},
  {path:'login', component:AdminLoginComponent},
  {path:'dashboard', component:EmployeeDashboardComponent},
  {path:'signup', component:SignupComponent}
  
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
