export class EmployeeModel{
    id:number = 0;
    firstname: string = '';
    lastname: string = '';
    email:string = '';
    mobile : string='';
    salary: string='';
}