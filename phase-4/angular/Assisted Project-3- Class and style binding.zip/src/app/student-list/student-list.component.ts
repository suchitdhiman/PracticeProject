import { Component } from '@angular/core';

@Component({
  selector: 'app-student-list',
  template: `
    <p>
      student-list works!
    </p>
  `,
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent {

}
