import { ColouringDirective } from './../../../../directive/src/app/colouring.directive';
import { Component } from '@angular/core';

@Component({
  selector: 'app-country-list',
  template: `
    <p>
      country-list works!
    </p>
  `,
  styles: [
    `p{
      Color:yellow;
    }`
  ]
})
export class CountryListComponent {

}
