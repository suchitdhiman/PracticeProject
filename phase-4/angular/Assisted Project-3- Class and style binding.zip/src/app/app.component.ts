import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'suchit kumar';
//  enable=true;
//   disable = false;
  
//   getValue(val:any){
//     console.log(val);
//   }
//   getData(data:string){
//     console.log(data);
//     this.displayVal=data;
//   }
//   displayVal:string='';
}
