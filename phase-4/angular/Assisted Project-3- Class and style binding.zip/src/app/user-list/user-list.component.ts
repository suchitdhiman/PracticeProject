import { Component } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styles: [
    `.list{color:red}`
  ]
})
export class UserListComponent {

}
