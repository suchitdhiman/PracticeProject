import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gretting',
  templateUrl: './gretting.component.html',
  styleUrls: ['./gretting.component.css']
})
export class GrettingComponent implements OnInit {
  ngOnInit(): void {
      
  }
  name:string = "suchit";
  constructor(){}
    Greet():void{
      alert("hello everyone . I am"+ this.name);
    }

    productList: Array<any>=[
      {pname: "rice", price:200},
      {pname:"sugar", price:50}
    ];
    show:boolean=true;
  }


